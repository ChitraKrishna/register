﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Registration_Login.Models
{
    public class CustomerDbOperation
    {

    }
}
