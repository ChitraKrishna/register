﻿using Microsoft.Data.SqlClient;
using Microsoft.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Registration_Login.Models
{
    public class DbConnect
    {
        public SqlConnection connection;
        public DbConnect()
        {
            connection = new SqlConnection();
        }
    }
}
